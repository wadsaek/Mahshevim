
let slideIndex = 0;
function showSlides() {
    let but = document.getElementById("but");
    but.style.display = "none";
    let slides = document.getElementsByClassName("img");
    slides[0].style.display = "none";
    slides[1].style.display = "none";
    slideIndex++;
    if (slideIndex > 2) { slideIndex = 1 }
    slides[slideIndex - 1].style.display = "block";
    setTimeout(showSlides, 2000);
}

let index = 4;
function animChange() {
    let slides = document.getElementsByClassName("img");
    
    switch (index) {
        case 1:
            for (let i = 0; i < 2; i++) {
                slides[i].classList.remove("img-anim-1");
                slides[i].classList.add("img-anim-2");
            }
            index = 2;
            break;

        case 2:
            for (let i = 0; i < 2; i++) {
                slides[i].classList.remove("img-anim-2");
                slides[i].classList.add("img-anim-3");
            }
            index = 3;
            break;
        case 3:
            for (let i = 0; i < 2; i++) {
                slides[i].classList.remove("img-anim-3");
                slides[i].classList.add("img-anim-4");
            }
            index = 4;
            break;
        case 4:
            for (let i = 0; i < 2; i++) {
                slides[i].classList.remove("img-anim-4");
                slides[i].classList.add("img-anim-1");
            }
            index = 1;
            break;
    }
    
    setTimeout(animChange, 4000);
}

